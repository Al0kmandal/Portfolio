function A() {
    alert("Submitted Successfully. Please close the tab.");
}
