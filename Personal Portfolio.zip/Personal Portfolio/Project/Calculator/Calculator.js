function getNumbers() {
    const n1 = parseFloat(document.getElementById("1n").value);
    const n2 = parseFloat(document.getElementById("2n").value);
    return { n1, n2 };
}

function displayResult(result) {
    document.getElementById("result").value = result;
}

function clearFields() {
    document.getElementById("1n").value = '';
    document.getElementById("2n").value = '';
    document.getElementById("result").value = '';
}

function add() {
    const { n1, n2 } = getNumbers();
    displayResult(n1 + n2);
}

function sub() {
    const { n1, n2 } = getNumbers();
    displayResult(n1 - n2);
}

function mul() {
    const { n1, n2 } = getNumbers();
    displayResult(n1 * n2);
}

function div() {
    const { n1, n2 } = getNumbers();
    displayResult(n1 / n2);
}

function mod() {
    const { n1, n2 } = getNumbers();
    displayResult(n1 % n2);
}

function exp() {
    const { n1, n2 } = getNumbers();
    displayResult(Math.pow(n1, n2));
}

function sqrt() {
    const n1 = parseFloat(document.getElementById("1n").value);
    displayResult(Math.sqrt(n1));
}

function percent() {
    const { n1, n2 } = getNumbers();
    displayResult((n1 / 100) * n2);
}